from tqdm import tqdm
from heapq import *
import random
import time
import datetime

class Optimizer:
    def __init__(self, heuristic_signup, heuristic_wasted): #, heuristic_useless, heuristic_signup, heuristic_bookcount, heuristic_realdays, trim):
        self.books = []
        self.libraries = []
        self.max = 0

        self.used_libraries = []

        self.T = 0

        self.heuristic_signup = heuristic_signup
        self.heuristic_wasted = heuristic_wasted
        # self.heuristic_useless = heuristic_useless
        # self.heuristic_signup = heuristic_signup
        # self.heuristic_bookcount = heuristic_bookcount
        # self.heuristic_realdays = heuristic_realdays
        # self.trim = trim

    def init(self):
        pass

    def preprocess(self):
        for book in tqdm(self.books):
            book.calc_library_scores()
        # print(self.orders[1], self.orders[1].orders[:20])

    def optimize(self):
        self.optimize_firstRun()
        # self.optimize_secondRun()
        self.analyze()

    def optimize2(self):
        self.start = time.time()
        candidates = 0

        for book in sorted(self.books, key=lambda book: book.score, reverse=True):
            for library in book.libraries:
                library.virtualBooks.append(book)

        i = 0
        while True:
            sortedLibraries = sorted(
                filter(lambda lib: not lib.done, self.libraries),
                key=lambda lib: lib.calc_virtual_score(),
                reverse=True
            )

            if len(sortedLibraries) == 0:
                break

            library = sortedLibraries[0]

            if (library.calc_virtual_score() == 0):
                break

            # print("Added", library, "with score", -candidates[0][0], flush=True)
            self.used_libraries.append(library)
            library.finish2()
            self.T += library.signup

            if (i % 20 == 0):
                REMAINING = round(
                    (self.max / (self.T + 0.01) * (time.time() - self.start))
                    - (time.time() - self.start)
                )

            print("\r                                               ", end="")
            print(
                "\r%d/%d (%02.02f%%, remaining: %s)" % (
                    self.T,
                    self.max,
                    self.T / self.max * 100,
                    datetime.timedelta(
                        seconds=REMAINING
                    )
                ),
                end=""
            )
            i+= 1

        for library in self.used_libraries:
            library.scanned_books = []

        # E libs = [602, 972, 522, 100, 717, 157, 72, 715, 466, 61, 393, 390, 59, 708, 37, 813, 87, 952, 607, 933, 902, 693, 506, 244, 27, 158, 959, 970, 665, 82, 779, 239, 388, 69, 848, 894, 969, 589, 304, 944, 600, 594, 245, 209, 597, 443, 808, 178, 690, 4, 626, 0, 495, 736, 854, 478, 491, 387, 23, 241, 844, 343, 476, 125, 447, 700, 270, 772, 691, 350, 148, 575, 232, 669, 678, 971, 112, 520, 140, 795, 828, 830, 267, 320, 639, 653, 512, 566, 71, 793, 366, 852, 621, 80, 606, 428, 536, 455, 630, 737, 633, 316, 676, 411, 56, 650, 105, 191, 569, 160, 798, 242, 834, 510, 358, 333, 45, 179, 809, 62, 389, 336, 323, 21, 151, 273, 472, 184, 234, 911, 332, 973, 709, 457, 950, 646, 200, 233, 687, 516, 128, 773, 202, 252, 716, 543, 135, 85, 571, 805, 164, 66, 81, 936, 565]
        # # C libs
        # # libs = [1949, 8696, 4871, 6550, 8384, 4705, 5724, 2610, 3428, 8530, 2297, 7327, 8728, 9772, 8738, 6897, 5523, 4758, 1045, 349, 6241, 8691, 7491, 1864, 627, 7281, 1634, 8917, 8791, 6871, 8617, 9829, 4193, 2359, 9447, 3953, 661, 5771, 8181, 8887, 53, 9255, 6644, 5348, 1161, 7984, 18, 177, 1760, 7819, 7358, 7989, 5134, 3938, 4074, 9092, 8149, 7791, 2882, 9128, 2380, 9855, 111, 416, 2006, 7709, 650, 1349, 5804, 5020, 198, 5339, 2346, 8490, 3679, 8005, 8758, 8279, 1023, 806, 1653, 2754, 122, 4138, 6338, 1737, 6636, 5263, 6063, 6754, 6979, 5707, 6441, 1448, 4460, 2732, 2394, 1283, 8226, 5311, 4592, 9053, 7511, 2415, 1348, 555, 5023, 9927, 8050, 1356, 6213, 4059, 7075, 1549, 2044, 2737, 751, 6202, 8124, 4924, 2939, 2144, 4112, 7305, 2652, 587, 479, 752, 7201, 5853, 8283, 2942, 6253, 7021, 5064, 6997, 7841, 7104, 220, 1004, 8505, 6772, 6953, 9985, 1201, 8795, 4439, 3124, 5219, 7308, 5851, 6313, 6342, 9367, 9316, 2541, 7731, 5912, 9027, 4589, 6783, 906, 2919, 4717, 399, 7368, 4277, 6976, 4637, 9218, 9918, 1296, 3546, 2097, 7839, 7078, 9097, 7786, 9610, 8285, 7956, 1427, 8109, 7630, 8449, 6760, 29, 3245, 5569, 9294, 7175, 462, 3854, 6115, 5687, 7193, 9948, 2863, 2901, 561, 1476, 1229, 2143, 5857, 2426, 1668, 9100, 2312, 4386, 8409, 7010, 6588, 414, 5555, 5065, 9566, 3277, 1800, 115, 3525, 3993, 7038, 1195, 1967, 7285, 2943, 92, 4535, 2110, 1432, 3991, 3548, 5532, 1559, 973, 7407, 5360, 7293, 2017, 2339, 5789, 6960, 5345, 9647, 1351, 7582, 3631, 2868, 2904, 3483, 4284, 6698, 917, 7179, 7438, 1789, 3981, 5390, 8260, 2252, 6025, 61, 6915, 1307, 4556, 8981, 1342, 8677, 350, 2075, 4709, 9423, 820, 7344, 4893, 5604, 2504, 6235, 2469, 3148, 1109, 8056, 3967, 5635, 8628, 7995, 3612, 2548, 3216, 6129, 4563, 6977, 2137, 2651, 1642, 3868, 3944, 6416, 6054, 7555, 7914, 3246, 5107, 9847, 8390, 4704, 7833, 9564, 3720, 6229, 3025, 6215, 2590, 5551, 3742, 4506, 4631, 9061, 6916, 7937, 3202, 141, 5002, 7645, 6185, 5510, 3730, 4330, 3876, 7494, 1659, 2830, 2276, 9460, 2440, 7259, 180, 2250, 2994, 7124, 1154, 6386, 7360, 3318, 6779, 4252, 1617, 3342, 9095, 3707, 5097, 3837, 4813, 6152, 2595, 2567, 5397, 2497, 2977, 9489, 4614, 2819, 3091, 9686, 4645, 8931, 9833, 156, 458, 9108, 1397, 7120, 9540, 8518, 1679, 7294, 9291, 4626, 2608, 8314, 72, 7243, 4457, 3726, 1478, 4979, 2848, 9751, 3794, 5091, 3550, 4892, 8582, 9203, 4618, 6603, 3719, 868, 2457, 3586, 7493, 9486, 6006, 8989, 733, 6957, 5589, 4037, 5966, 5117, 1970, 205, 8648, 4395, 2200, 8177, 8839, 7445, 1331, 4847, 9239, 3852, 165, 2928, 7096, 5805, 4496, 88, 2510, 2161, 4380, 5426, 3552, 4319, 3764, 7801, 6900, 6079, 5565, 794, 6517, 1985, 5172, 2890, 3919, 9508, 9733, 7658, 1133, 5561, 242, 1557, 4803, 693, 1777, 8792, 6893, 526, 7967, 9080, 5357, 7575, 4278, 8098, 8912, 7729, 8095, 3597, 1515, 6387, 9081, 7737, 9096, 1973, 5202, 6468, 2998, 3737, 5818, 6493, 490, 4038, 1420, 7424, 5931, 2664, 2783, 8178, 9548, 4194, 7512, 381, 9265, 6464, 1488, 787, 1978, 1137, 9160, 2973, 9629, 8366, 667, 832, 1504, 5849, 3267, 5810, 9795, 6924, 5184, 5890, 7217, 417, 3877, 5607, 2786, 370, 1743, 1830, 4473, 1029, 7624, 7442, 7143, 703, 9315, 6485, 8521, 599, 9775, 4084, 81, 5171, 9992, 7881, 3907, 4072, 2269, 6446, 1241, 1948, 322, 4154, 6623, 8093, 6821, 829, 2119, 4951, 5558, 3729, 5471, 1596, 2138, 3134, 5761, 984, 3932, 5654, 4977, 3999, 9285, 1453, 5100, 7843, 2115, 7974, 1873, 7734, 4381, 2131, 5765, 694, 1989, 1868, 8591, 7963, 4713, 9761, 1164, 9200, 6134, 2126, 7644, 124, 9028, 1996, 1316, 673, 2722, 5811, 3698, 9002, 2738, 6885, 7261, 8392, 3568, 4170, 7666, 6792, 1024, 3470, 9934, 3626, 520, 5568, 8330, 3229, 6966, 2235, 4364, 9960, 7838, 8828, 9616, 3883, 5942, 293, 3678, 8618, 9963, 1246, 2257, 314, 7363, 2881, 3871, 69, 9017, 6826, 8659, 9534, 1886, 3771, 8211, 8831, 5502, 6380, 993, 8254, 7042, 521, 4669, 5888, 7007, 8893, 9507, 2900, 8222, 4660, 8902, 3050, 918, 9168, 5437, 1984, 79, 2557, 1044, 9392, 4065, 6679, 6076, 2111, 5798, 8958, 5933, 4374, 6212, 5873, 4215, 8869, 811, 5113, 4397, 3963, 1883, 410, 657, 8101, 5423, 3459, 8008, 1899, 5193, 4101, 969, 5272, 1425, 2047, 438, 4116, 3553, 1927, 4011, 3413, 2162, 9227, 6418, 8818, 1361, 9872, 7611, 4463, 7025, 4231, 8644, 8536, 6751, 7302, 248, 6793, 3211, 498, 2354, 6236, 3034, 783, 3874, 5513, 7804, 1584, 7177, 7166, 6232, 4164, 7258, 5286, 7280, 9353, 1711, 5971, 3186, 8261, 5269, 2657, 6715, 6370, 1682, 1226, 5030, 5438, 3792, 1618, 5227, 6618, 6665, 7803, 3347, 6330, 6929, 6423, 4275, 9596, 2991, 8848, 4986, 336, 6724, 310, 5045, 983, 4058, 9916, 6355, 1878, 1110, 3622, 9667, 6980, 2021, 7296, 9724, 2366, 5990, 8751, 9506, 25, 3955, 9767, 9701, 2986, 8587, 7726, 3423, 3094, 3394, 7148, 4750, 6763, 5254, 9077, 83, 4919, 319, 3593, 9103, 8180, 9143, 4026, 1807, 5200, 4402, 4677, 6218, 3313, 8843, 6349, 2990, 4430, 7452, 8128, 6805, 1037, 6634, 8488, 6001, 3307, 3818, 8363, 3454, 445, 814, 5950, 5697, 1002, 3632, 9574, 6084, 1731, 4355, 6367, 1960, 1345, 1824, 3865, 3998, 5547, 930, 4246, 8624, 6794, 1014, 7039, 613, 7191, 4613, 9070, 4975, 1516, 4606, 2923, 6609, 9013, 337, 8070, 2892, 2778, 7674, 7977, 9302, 5530, 9060, 9638, 3694, 897, 1394, 7506, 9124, 7218, 963, 8338, 335, 6940, 4451, 6209, 1048, 1844, 7069, 6470, 296, 9871, 6619, 4241, 8793, 4830, 2414, 3080, 4749, 1992, 6484, 1464, 317, 682, 9836, 6285, 585, 7534, 3334, 6109, 4367, 9064, 9406, 7474, 9810, 1550, 486, 3212, 6442, 6673, 9676, 2687, 5525, 1303, 4891, 5664, 3799, 9106, 5450, 2655, 2798, 1826, 5, 9204, 1723, 5374, 2329, 1813, 3617, 4742, 9809, 3218, 8427, 4001, 3472, 3947, 7205, 8269, 5388, 9110, 9336, 4963, 3247, 8300, 6153, 4177, 354, 4490, 4855, 6060, 9562, 8422, 5291, 3243, 1752, 2086, 706, 5999, 7770, 4351, 7822, 5159, 9432, 6228, 6239, 6931, 3254, 8138, 5956, 8388, 9517, 3290, 3289, 4933, 3892, 9787, 2331, 9275, 8122, 3156, 1676, 8890, 1940, 4009, 9221, 1065, 2824, 2535, 2960, 7312, 6743, 7071, 2941, 1415, 6717, 6902, 2565, 8033, 2268, 5585, 8328, 2147, 2976, 2293, 3684, 2520, 6237, 470, 1661, 8137, 440, 6939, 4148, 3507, 9553, 4383, 1525, 5889, 2760, 7830, 383, 8198, 9550, 1249, 2079, 9429, 1966, 4393, 6633, 7601, 3915, 8572, 840, 34, 6733, 684, 5123, 16, 1803, 9461, 8157, 2214, 8569, 3564, 4819, 8982, 4828, 891, 7088, 3580, 9692, 3406, 5281, 147, 8404, 7736, 2058, 3605, 637, 3301, 6612, 517, 7072, 6899, 465, 1028, 5835, 9641, 38, 5177, 825, 3891, 4817, 9350, 9007, 2375, 6251, 7702, 3022, 9250, 3545, 6492, 7954, 7462, 8663, 1565, 1922, 8616, 5484, 6250, 407, 3740, 672, 5590, 8683, 3167, 5427, 3420, 360, 7290, 3352, 8583, 7594, 5175, 9889, 7076, 6017, 8262, 8174, 5760, 107, 3941, 8717, 2317, 5830, 3572, 7045, 3192, 4083, 4297, 1876, 7050, 3418, 2585, 2385, 4055, 2260, 548, 3463, 283, 6340, 5668, 8482, 3331, 8910, 4213, 7875, 3369, 2429, 5252, 3859, 237, 339, 8649, 2776, 8139, 6669, 7164, 9671, 3722, 3767, 3491, 7871, 3817, 6179, 456, 896, 7291, 201, 429, 5583, 4320, 3145, 3215, 3774, 6597, 7338, 4661, 9496, 9560, 5917, 4582, 3065, 9748, 9986, 679, 6992, 6995, 5282, 3027, 500, 2631, 6602, 3954, 1224, 9643, 1640, 1561, 8654, 7159, 6246, 3708, 2908, 5016, 8773, 2159, 4068, 8516, 4019, 3623, 3220, 4316, 7515, 908, 3399, 7099, 1189, 1963, 6188, 5891, 5968, 3921, 9760, 3473, 7256, 2632, 3607, 537, 8749, 1615, 436, 2887, 9182, 5957, 1601, 4160, 2984, 2265, 1529, 4434, 2244, 3997, 136, 142, 389, 1139, 1288, 2013, 1481, 4437, 2703, 9752, 1234, 2173, 2165, 4250, 5767, 2537, 1041, 1401, 5340, 2959, 5321, 8861, 3557, 5285, 427, 9305, 4100, 9710, 5896, 1403, 4387, 3529, 9266, 2671, 3978, 3162, 542, 4518, 5267, 245, 9153, 4086, 2365, 1900, 8858, 3520, 3809, 6965, 9573]
        # for i in libs:
        #     library = self.libraries[i]
        #     library.T = self.T
        #     self.T += library.signup
        #     self.used_libraries.append(library)

        for book in sorted(self.books, key=lambda b: b.score):
            book.init_libraries()

        i = 0
        while True:
            print("ITERATION", i, flush=True)
            changed = 0
            for book in tqdm(self.books):
                library = book.find_best_library()

                if library is not None:
                    changed += 1
            print(" => changed: ", changed)
            i+= 1
            if changed == 0:
                break

        for library in self.used_libraries:
            for tup in library.booksPrioQueue:
                library.scanned_books.append(tup[1])

        # self.analyze()



    def optimize_firstRun(self):
        # self.preprocess()

        # for book in self.books:
        #     print(book.libraries)
        # exit


        i = 0
        while True:
            bestLibraries = []
            for library in self.libraries:
                if library.done:
                    continue

                score = library.get_score()
                if score > 0:
                    # print((score, library))
                    heappush(bestLibraries, (-score, library))

            bestLibraries = bestLibraries[:self.trim]

            for tup in bestLibraries:
                if (i % 21 == 0):
                    i += 1
                    print("Aded 20, total:", len(self.used_libraries), flush=True)
                # print("Adding", tup)
                library = tup[1]

                library.finish()
                library.done = True
                if len(library.scanned_books) > 0:
                    self.used_libraries.append(library)
                    self.T += library.signup
                    i += 1

            if len(bestLibraries) == 0:
                break

    def optimize_secondRun(self):
        # self.preprocess()

        # for book in self.books:
        #     print(book.libraries)
        # exit

        # for book in self.books:
        #     book.done = False
        #     book.library = None

        # self.used_libraries = sorted(
        #     self.used_libraries,
        #     key=lambda library: library.signup - library.T / 1000,
        # )

        # for library in self.libraries:
        #     library.done = False
        #     library.T = 0

        # self.T = 0

        i = 0

        for library in tqdm(self.used_libraries):
            for book in library.scanned_books:
                book.done = False

            raw_score = library.raw_score(library.T)
            shorter_signup = list(filter(
                lambda lib: lib.signup <= library.signup and lib.T == -1,
                self.libraries
            ))

            best_score = raw_score
            best_better_lib = None
            for lib in shorter_signup:
                score = lib.raw_score(library.T)
                if (score > best_score):
                    best_score = score
                    best_better_lib = lib

            if best_better_lib is not None:
                T = self.T
                self.T = library.T
                self.used_libraries[i] = best_better_lib
                best_better_lib.finish()
                library.done = False
                library.scanned_books = []
                library.minScanScore = 0
                library.wastedTime = 0
                library.T = -1

                print("FOUND BETTER:", library, raw_score, "=>", best_better_lib, best_score, flush=True)

                if (library.T - best_better_lib.T) > 0:
                    print("INCREASED", flush=True)
                    for lib in self.used_libraries[i+1:]:
                        lib.T -= (library.T - best_better_lib.T)
                        if lib.wastedTime == 0:
                            self.T = lib.T

                            lib.minScanScore = 0
                            for book in lib.scanned_books:
                                book.done = False
                            lib.scanned_books = []
                            lib.wastedTime = 0
                            lib.T = -1

                            lib.finish()
                self.T = T
            else:
                for book in library.scanned_books:
                    book.done = True

            i += 1
            # if library.wastedTime >= 0:
            #     print("Lib", library, "wasted:  %-3d" % library.wastedTime, "T:", "%i/%i" % (library.T, self.max) + " =>", raw_score)
            # else:
            #     print("Lib", library, "no waste!   ", "T:", "%i/%i" % (library.T, self.max) + " =>", raw_score)
            # if (i % 21 == 0):
            #     i += 1
            #     print("Real Aded 20, total:", len(self.used_libraries))

            # library.finish_with_later(self.used_libraries[j:])
            # library.done = True
            # if len(library.scanned_books) > 0:
            #     self.used_libraries.append(library)
            #     self.T += library.signup
            #     i += 1
            # j += 1

    def analyze(self):
        for library in list(sorted(
            self.used_libraries,
            key=lambda library: library.signup
        )):
        #     books = ""
        #     for book in sorted(library.books, key=lambda book: book.score, reverse=True):
        #         if book in library.scanned_books:
        #             books += "S"
        #         elif book.done is True:
        #             books += "*"
        #         else:
        #             books += "-"

            print(library, self.max - library.T, len(library.scanned_books) / library.rate)

        # books = ""
        # for book in sorted(self.books, key=lambda book: book.score, reverse=True):
        #     if book.done is True:
        #         books += "S"
        #     else:
        #         books += "-"
        # print(books)

