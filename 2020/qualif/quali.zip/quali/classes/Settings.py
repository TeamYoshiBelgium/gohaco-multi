
# This is a class that is meant to contain only
# static variables or functions, such that they
# can be used in a global fashion throughout the
# project.

class Settings:
    version = "0.1"
